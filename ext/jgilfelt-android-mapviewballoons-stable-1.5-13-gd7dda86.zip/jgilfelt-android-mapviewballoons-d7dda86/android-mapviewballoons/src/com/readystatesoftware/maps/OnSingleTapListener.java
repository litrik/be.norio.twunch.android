package com.readystatesoftware.maps;

import android.view.MotionEvent;

public interface OnSingleTapListener {
	public boolean onSingleTap(MotionEvent e);
}
